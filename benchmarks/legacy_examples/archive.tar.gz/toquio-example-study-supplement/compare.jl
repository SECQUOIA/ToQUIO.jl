using JuMP, ToQUIO, TOML, SHA, Random, LinearAlgebra, Pkg
const M = ToQUIO.MOI
include("/workspace/benchmarks/CQTBenchmarks.jl")
const S = CQTBenchmarks
const PROTOCOL = TOML.parsefile("/study/protocol.toml")
const ARMS = (("native", NativeEncoding()), ("radix4", RadixEncoding(; levels=4)),
    ("bounded4-cap2", BoundedEncoding(; levels=4, max_weight=2)),
    ("binary-radix2", RadixEncoding(; levels=2)))

function build(code, strategy)
    mod = Module(gensym(:LegacyExample))
    Core.eval(mod, :(const ARM = $strategy))
    Base.include_string(mod, replace(code, "ToQUIO.Optimizer()" =>
        "ToQUIO.Optimizer(; encoding=ARM, max_encoded_variables=256)"), "legacy-example.jl")
    optimizer = getfield(mod, :optimizer)
    model = getfield(mod, :model)
    timed = @timed optimize!(model)
    return optimizer, timed.time, timed.bytes
end

function source_functions(oracle)
    variables = oracle.data[:source_variables]
    pos = Dict(v => i for (i,v) in enumerate(variables))
    source = oracle.source_model
    F = M.get(source, M.ObjectiveFunctionType())
    objective = M.get(source, M.ObjectiveFunction{F}())
    value(x) = M.Utilities.eval_variables(v -> x[pos[v]], objective)
    constraints = oracle.data[:source_constraints]
    function feasible(x)
        for c in constraints
            z = c.func isa M.VariableIndex ? x[pos[c.func]] :
                M.Utilities.eval_variables(v -> x[pos[v]], c.func)
            s = c.set
            ok = s isa M.EqualTo ? abs(z-s.value) <= 1e-7 :
                 s isa M.LessThan ? z <= s.upper+1e-7 :
                 s isa M.GreaterThan ? z >= s.lower-1e-7 :
                 s isa M.Interval ? s.lower-1e-7 <= z <= s.upper+1e-7 :
                 s isa M.Integer ? isinteger(z) :
                 s isa M.ZeroOne ? z in (0,1) : error("Unhandled source set")
            ok || return false
        end
        return true
    end
    sense = M.get(source, M.ObjectiveSense()) == M.MIN_SENSE ? "min" : "max"
    return value, feasible, sense
end

function reference(oracle, value, feasible, sense)
    n = length(oracle.data[:source_variables])
    lower, upper = Int.(oracle.data[:l][1:n]), Int.(oracle.data[:u][1:n])
    states = prod(big.(upper-lower.+1))
    states <= PROTOCOL["max_reference_states"] || error("Reference state cap")
    best, point, count = nothing, Int[], 0
    for x in Iterators.product((l:u for (l,u) in zip(lower,upper))...)
        if feasible(x)
            count += 1
            y = value(x)
            if isnothing(best) || (sense == "min" ? y < best : y > best)
                best, point = y, collect(x)
            end
        end
    end
    isnothing(best) && error("Source example has no feasible state")
    return Dict("objective"=>best, "point"=>point, "box_states"=>Int(states),
        "feasible_states"=>count, "sense"=>sense,
        "method"=>"complete-original-integer-box-enumeration-Float64-objective")
end

function check_encoding(opt, oracle, p, native_p, ref, feasible)
    opt.data[:rho] == oracle.data[:rho] || error("Changed source penalties")
    state = Int.(S.native_source_point(oracle, ref["point"]; fill_slacks=true))
    digits = lift_native_state(opt, state)
    project_native_state(opt, digits) == state || error("Reference lift")
    is_feasible(opt, digits) || error("Reference source feasibility")
    isapprox(S.energy(p,digits), ref["objective"]; atol=1e-7, rtol=1e-10) ||
        error("Reference energy differs from source")
    rng = MersenneTwister(85401)
    for i in 1:100
        z = [rand(rng,l:u) for (l,u) in zip(p.lower,p.upper)]
        native = project_native_state(opt,z)
        projected = project_original_state(opt,z)
        x = [projected[v] for v in oracle.data[:source_variables]]
        isapprox(S.energy(p,z), S.energy(native_p,native); atol=1e-7, rtol=1e-10) ||
            error("Random polynomial equivalence failed")
        feasible(x) == is_feasible(opt,z) || error("Independent source feasibility differs")
    end
    return Dict("reference_lift"=>true, "random_states"=>100,
        "unchanged_penalties"=>true, "polynomial_equivalence"=>true)
end

function run_arm(opt, oracle, p, ref, value, feasible, sense)
    n = length(oracle.data[:source_variables])
    # Public projection is validated above. Cache the exact emitted affine map
    # for the observer so metadata dictionary allocation does not dominate search.
    zero_native = Float64.(p.lower)
    offset = project_native_state(opt,zero_native)
    A = zeros(Float64,length(offset),length(p.g))
    for j in eachindex(p.g)
        z = copy(zero_native); z[j] += 1
        # Fixed target variables cannot be perturbed through the public projector.
        if p.lower[j] != p.upper[j]
            A[:,j] = project_native_state(opt,z) - offset
        end
    end
    origin = offset - A*zero_native
    function observe(z)
        x = (origin + A*z)[1:n]
        f = feasible(x)
        y = value(x)
        target = f && abs(y-ref["objective"]) <= 1e-7*max(1,abs(ref["objective"]))
        return (source=x, feasible=f, objective=y, sense=sense, target=target)
    end
    function initialize(rng)
        native = [rand(rng,Int(l):Int(u)) for (l,u) in zip(oracle.data[:l],oracle.data[:u])]
        return lift_native_state(opt,native)
    end
    scale = max(1.0,maximum(abs,p.G),maximum(abs,p.g))
    # Warm the exact observer/kernel before collecting wall-clock-limited runs.
    S.metropolis(p,initialize,observe;seed=85000,reserved_proposals=8,max_seconds=Inf,
        energy_scale=scale,check_deltas=true)
    runs = Dict{String,Any}[]
    for seed in PROTOCOL["seed_start"]:(PROTOCOL["seed_start"]+PROTOCOL["restarts"]-1)
        r = S.metropolis(p,initialize,observe;seed,
            reserved_proposals=PROTOCOL["reserved_proposals"],max_seconds=PROTOCOL["max_seconds"],
            energy_scale=scale,check_deltas=false)
        # Audit every stored state with public projection/feasibility and source equation.
        for sample in r["samples"]
            z = sample["state"]
            public = project_original_state(opt,z)
            x = [public[v] for v in oracle.data[:source_variables]]
            x == sample["source"] || error("Observer decoding mismatch")
            is_feasible(opt,z) == sample["source_feasible"] || error("Sample feasibility mismatch")
            value(x) == sample["source_objective"] || error("Sample objective mismatch")
        end
        push!(runs,r)
    end
    return runs
end

function main()
    @assert pathof(ToQUIO) == "/workspace/src/ToQUIO.jl"
    result = Dict{String,Any}("source_commit"=>PROTOCOL["source_commit"],
        "julia_version"=>string(VERSION), "source_path"=>pathof(ToQUIO),
        "moi_version"=>string(Pkg.dependencies()[Base.PkgId(M).uuid].version),
        "protocol_sha256"=>bytes2hex(sha256(read("/study/protocol.toml"))),
        "script_sha256"=>bytes2hex(sha256(read(@__FILE__))),
        "limitations"=>["exploratory, no tuning or general superiority claim",
            "single fixed heuristic, 10 paired starts per example, no statistical significance claim",
            "binary-radix2 uses ToQUIO compiler; not ToQUBO",
            "fixed max-coefficient temperature scaling changes search behavior across targets",
            "source feasibility differs from generated slack consistency",
            "Float64 source objective evaluation, not exact arithmetic certificate"],
        "examples"=>Dict{String,Any}[])
    for ex in PROTOCOL["examples"]
        title, code = ex["title"], ex["code"]
        oracle,_,_ = build(code,NativeEncoding())
        value,feasible,sense = source_functions(oracle)
        ref = reference(oracle,value,feasible,sense)
        native_p,_ = S.polynomial_from_moi(oracle.target_model)
        row = Dict{String,Any}("title"=>title,"source_block_sha256"=>ex["source_block_sha256"],
            "reference"=>ref,"arms"=>Dict{String,Any}[])
        for (name,strategy) in ARMS
            build(code,strategy) # First-call compile/JIT excluded from warm measurement.
            opt,seconds,bytes = build(code,strategy)
            p,_ = S.polynomial_from_moi(opt.target_model)
            checked = check_encoding(opt,oracle,p,native_p,ref,feasible)
            runs = run_arm(opt,oracle,p,ref,value,feasible,sense)
            arm = Dict("arm"=>name,"warm_optimize_seconds"=>seconds,"warm_optimize_bytes"=>bytes,
                "structure"=>S.structural_metrics(p),"validation"=>checked,"runs"=>runs)
            push!(row["arms"],arm)
            println(title," | ",name," n=",length(p.g)," target=",
                count(r->r["timely_target"],runs),"/",length(runs)," feasible=",
                count(r->r["any_feasible"],runs),"/",length(runs));flush(stdout)
        end
        push!(result["examples"],row)
        open("/study/results.partial.toml","w") do io
            TOML.print(io,result;sorted=true)
        end
    end
    open("/study/results.toml","w") do io
        TOML.print(io,result;sorted=true)
    end
    println("All legacy examples completed.")
end
main()
